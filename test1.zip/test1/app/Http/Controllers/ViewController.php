<?php

namespace App\Http\Controllers;

use App\Comic;
use Illuminate\Http\Request;

class ViewController extends Controller
{
    public function index()
    {
        $comics = Comic::all(); // Fetch all comics from the database
        return view('view.index', compact('comics'));
}
public function show($id)
    {
        $comic = Comic::findOrFail($id);
        return view('view.show', compact('comic'));
    }
    
    public function categories()
    {
        $comics = Comic::all(); // Fetch all comics from the database
        return view('view.categories', compact('comics'));
    }    
}

