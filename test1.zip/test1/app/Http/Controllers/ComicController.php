<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Comic;
use Illuminate\Support\Facades\Storage;

class ComicController extends Controller
{
    public function index()
    {
        $comics = \App\Comic::all();
        return view('comics.index', compact('comics'));
    }

    public function create()
    {
        return view('comics.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'description' => 'nullable',
            'author' => 'nullable',
            'cover_image' => 'image|nullable|max:1999' // max 2MB
        ]);

        // Handle File Upload
        if ($request->hasFile('cover_image')) {
            // Get filename with extension
            $filenameWithExt = $request->file('cover_image')->getClientOriginalName();
            // Get just filename
            $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
            // Get just extension
            $extension = $request->file('cover_image')->getClientOriginalExtension();
            // Filename to store
            $fileNameToStore = $filename.'_'.time().'.'.$extension;
            // Upload Image
            $path = $request->file('cover_image')->storeAs('public/cover_images', $fileNameToStore);
        } else {
            $fileNameToStore = 'noimage.jpg';
        }

        // Create Comic
        $comic = new \App\Comic;
        $comic->title = $request->input('title');
        $comic->description = $request->input('description');
        $comic->author = $request->input('author');
        $comic->cover_image = $fileNameToStore;
        $comic->save();

        return redirect()->route('comics.index')->with('success', 'Komik berhasil ditambahkan');
    }

    public function show($id)
    {
        $comic = \App\Comic::findOrFail($id);
        return view('comics.show', compact('comic'));
    }

    public function edit($id)
    {
        $comic = \App\Comic::findOrFail($id);
        return view('comics.edit', compact('comic'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'title' => 'required',
            'description' => 'nullable',
            'author' => 'nullable',
            'cover_image' => 'image|nullable|max:1000000'
        ]);

        
        if ($request->hasFile('cover_image')) {
           
            $filenameWithExt = $request->file('cover_image')->getClientOriginalName();
      
            $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
      
            $extension = $request->file('cover_image')->getClientOriginalExtension();
        
            $fileNameToStore = $filename.'_'.time().'.'.$extension;
     
            $path = $request->file('cover_image')->storeAs('public/cover_images', $fileNameToStore);
        }
-
        $comic = \App\Comic::findOrFail($id);
        $comic->title = $request->input('title');
        $comic->description = $request->input('description');
        $comic->author = $request->input('author');
        if ($request->hasFile('cover_image')) {
            Storage::delete('public/cover_images/'.$comic->cover_image); // Delete old image
            $comic->cover_image = $fileNameToStore;
        }
        $comic->save();

        return redirect()->route('comics.index')->with('success', 'Komik berhasil diperbarui');
    }

    public function destroy($id)
    {
        $comic = \App\Comic::findOrFail($id);

        if ($comic->cover_image != 'noimage.jpg') {
            Storage::delete('public/cover_images/'.$comic->cover_image);
        }
        $comic->delete();
        return redirect()->route('comics.index')->with('success', 'Komik berhasil dihapus');
    }

    public function search(Request $request)
    {
        $search = $request->input('search');

         $comics = \App\Comic::where('title', 'like', "%$search%")
                        ->get();

    return view('comics.index', compact('comics'));
}
}

