
@extends('layoutsAdmin.main')

@section('content')
    <div class="container">
        <h1>Daftar Komik</h1>
        <form action="{{ route('comics.search') }}" method="GET" class="form-inline mb-3">
        <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" name="search">
        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
         </form>

         <div class="row">
    @foreach ($comics as $comic)
        <div class="col-md-3">
            <div class="card mb-4">
                <img src="{{ asset('storage/cover_images/' . $comic->cover_image) }}" class="card-img-top" alt="{{ $comic->title }}">
                <div class="card-body">
                    <h5 class="card-title">{{ $comic->title }}</h5>
                    <a href="{{ route('comics.edit', $comic->id) }}" class="btn btn-warning">Edit</a>
                    <form action="{{ route('comics.destroy', $comic->id) }}" method="POST" class="d-inline">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus komik ini?')">Hapus</button>
                    </form>
                </div>
            </div>
        </div>
    @endforeach
</div>
    </div>
@endsection

