@extends('layoutsView.main')

@section('content')
    <!-- Normal Breadcrumb Begin -->
    <section class="normal-breadcrumb set-bg" data-setbg="asset/img/normal-breadcrumb.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="normal__breadcrumb__text">
                        <h2>Login</h2>
                        <p>Welcome to Komik +62</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Normal Breadcrumb End -->

    <!-- Login Section Begin -->
    <section class="login spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="login__form">
                    <h3>Login</h3>
                    <form method="POST" action="{{ route('login.post') }}">
                        @csrf
                        <div class="input__item">
                            <input type="email" name="email" placeholder="Email address" value="{{ old('email') }}" required autocomplete="email" autofocus>
                            <span class="icon_mail"></span>
                        </div>
                        <div class="input__item">
                            <input type="password" name="password" placeholder="Password" required autocomplete="current-password">
                            <span class="icon_lock"></span>
                        </div>
                        <button type="submit" class="site-btn"><a href="{{ url('/') }}">Login Now</a></button>
                    </form>
                </div>
                <div class="register-link mt-3">
                    <p>Don't have an account? <a href="{{ route('registeruser') }}">Register now</a></p>
                </div>
                <div class="forgot-password-link mt-2">
                    <a href="#" class="forget_pass">Forgot Your Password?</a>
                </div>
            </div>
        </div>  
    </div>
</section>



    <!-- Login Section End -->
@endsection
