@extends('layoutsview.main')
@section('content')
<section class="product spad">
    <div class="container">
    <div class="row">
                            <div class="col-lg-8 col-md-8 col-sm-8">
                                <div class="section-title">
                                    <h4>Categories</h4>
                                </div>
                            </div>
                        </div>
                        <div class="row">
    @foreach ($comics->slice(0, 20) ?? [] as $comic)
    <div class="col-md-4 mb-4">
        <div class="card h-100">
            <a href="{{ route('view.show', ['id' => $comic->id]) }}">
                <img src="{{ asset('storage/cover_images/' . $comic->cover_image) }}" class="card-img-top" alt="{{ $comic->title }}">
            </a>
            <div class="card-body">
                <h5 class="card-title">
                    <a href="{{ route('view.show', ['id' => $comic->id]) }}" class="text-decoration-none text-dark">{{ $comic->title }}</a>
                </h5>
                <p class="card-text">{{ Str::limit($comic->description, 100) }}</p> <!-- Batasi deskripsi menjadi maksimal 100 karakter -->
            </div>
        </div>
    </div>
    @endforeach
</div>
    </div>
</section>
@endsection