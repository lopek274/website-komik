@extends('layoutsview.main')
@section('content')

<section class="hero">
    <div class="container">
        <div class="hero__slider owl-carousel">
            @foreach ($comics->slice(7, 4) ?? [] as $comic)
            <div class="hero__items set-bg" data-setbg="{{ asset('storage/cover_images/' . $comic->cover_image) }}">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="hero__text">
                            <h2 class="text-decoration-none text-dark">{{ $comic->title }}</h2>
                            <p class="card-text; text-decoration-none text-dark" >{{ Str::limit($comic->description, 100) }}</p>
                            <a href="{{ route('view.show', ['id' => $comic->id]) }}"><span>Read now</span> <i class="fa fa-angle-right"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>


    <section class="product spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="trending__product">
                        <div class="row">
                            <div class="col-lg-8 col-md-8 col-sm-8">
                                <div class="section-title">
                                    <h4>Trending Now</h4>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-4">
                                <div class="btn__all">
                                    <a href="#" class="primary-btn">View All <span class="arrow_right"></span></a>
                                </div>
                            </div>
                        </div>
                        <div class="row">
    @foreach ($comics->slice(0, 6) ?? [] as $comic)
    <div class="col-md-4 mb-4">
        <div class="card h-100">
            <a href="{{ route('view.show', ['id' => $comic->id]) }}">
                <img src="{{ asset('storage/cover_images/' . $comic->cover_image) }}" class="card-img-top" alt="{{ $comic->title }}">
            </a>
            <div class="card-body">
                <h5 class="card-title">
                    <a href="{{ route('view.show', ['id' => $comic->id]) }}" class="text-decoration-none text-dark">{{ $comic->title }}</a>
                </h5>
                <p class="card-text">{{ Str::limit($comic->description, 100) }}</p> <!-- Batasi deskripsi menjadi maksimal 100 karakter -->
            </div>
        </div>
    </div>
    @endforeach
</div>
                    </div>
                    <div class="popular__product">
                        <div class="row">
                            <div class="col-lg-8 col-md-8 col-sm-8">
                                <div class="section-title">
                                    <h4>Popular Shows</h4>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-4">
                                <div class="btn__all">
                                    <a href="#" class="primary-btn">View All <span class="arrow_right"></span></a>
                                </div>
                            </div>
                        </div>
                        <div class="row">
    @foreach ($comics->slice(6, 6) ?? [] as $comic)
    <div class="col-md-4 mb-4">
        <div class="card h-100">
            <a href="{{ route('view.show', ['id' => $comic->id]) }}">
                <img src="{{ asset('storage/cover_images/' . $comic->cover_image) }}" class="card-img-top" alt="{{ $comic->title }}">
            </a>
            <div class="card-body">
                <h5 class="card-title">
                    <a href="{{ route('view.show', ['id' => $comic->id]) }}" class="text-decoration-none text-dark">{{ $comic->title }}</a>
                </h5>
                <p class="card-text">{{ Str::limit($comic->description, 100) }}</p> <!-- Batasi deskripsi menjadi maksimal 100 karakter -->
            </div>
        </div>
    </div>
    @endforeach
</div>

                    </div>
                    <div class="recent__product">
                        <div class="row">
                            <div class="col-lg-8 col-md-8 col-sm-8">
                                <div class="section-title">
                                    <h4>Recently Added Shows</h4>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-4">
                                <div class="btn__all">
                                    <a href="#" class="primary-btn">View All <span class="arrow_right"></span></a>
                                </div>
                            </div>
                        </div>
                        <<div class="row">
    @foreach ($comics->slice(12, 6) ?? [] as $comic)
    <div class="col-md-4 mb-4">
        <div class="card h-100">
            <a href="{{ route('view.show', ['id' => $comic->id]) }}">
                <img src="{{ asset('storage/cover_images/' . $comic->cover_image) }}" class="card-img-top" alt="{{ $comic->title }}">
            </a>
            <div class="card-body">
                <h5 class="card-title">
                    <a href="{{ route('view.show', ['id' => $comic->id]) }}" class="text-decoration-none text-dark">{{ $comic->title }}</a>
                </h5>
                <p class="card-text">{{ Str::limit($comic->description, 100) }}</p> 
            </div>
        </div>
    </div>
    @endforeach
</div>

                    </div>
                    
                </div>
                <div class="col-lg-4 col-md-6 col-sm-8">
                    <div class="product__sidebar">
                        <div class="product__sidebar__view">
                            <div class="section-title">
                                <h5>Top Views</h5>
                            </div>
                            <ul class="filter__controls">
                                <li class="active" data-filter="*">Day</li>
                                <li data-filter=".week">Week</li>
                                <li data-filter=".month">Month</li>
                                <li data-filter=".years">Years</li>
                            </ul>
                            <div class="filter__gallery">
    <div class="row">
    <!-- Day Category -->
    <div class="col-md-6">
        @foreach ($comics->slice(0, 2) ?? [] as $comic)
        <div class="product__sidebar__view__item set-bg mix day"
             data-setbg="{{ asset('storage/cover_images/' . $comic->cover_image) }}">
            <a href="{{ route('view.show', ['id' => $comic->id]) }}" class="text-decoration-none text-dark">
                <h5>{{ $comic->title }}</h5>
            </a>
        </div>
        @endforeach
    </div>

    <!-- Week Category -->
    <div class="col-md-6">
        @foreach ($comics->slice(2, 2) ?? [] as $comic)
        <div class="product__sidebar__view__item set-bg mix week"
             data-setbg="{{ asset('storage/cover_images/' . $comic->cover_image) }}">
            <a href="{{ route('view.show', ['id' => $comic->id]) }}" class="text-decoration-none text-dark">
                <h5>{{ $comic->title }}</h5>
            </a>
            
        </div>
        @endforeach
    </div>

    <!-- Month Category -->
    <div class="col-md-6">
        @foreach ($comics->slice(4, 2) ?? [] as $comic)
        <div class="product__sidebar__view__item set-bg mix month"
             data-setbg="{{ asset('storage/cover_images/' . $comic->cover_image) }}">
            <a href="{{ route('view.show', ['id' => $comic->id]) }}" class="text-decoration-none text-dark">
                <h5>{{ $comic->title }}</h5>
            </a>
           
        </div>
        @endforeach
    </div>

    <!-- Years Category -->
    <div class="col-md-6">
        @foreach ($comics->slice(6, 2) ?? [] as $comic)
        <div class="product__sidebar__view__item set-bg mix years"
             data-setbg="{{ asset('storage/cover_images/' . $comic->cover_image) }}">
            <a href="{{ route('view.show', ['id' => $comic->id]) }}" class="text-decoration-none text-dark">
                <h5>{{ $comic->title }}</h5>
            </a>
           
        </div>
        @endforeach
    </div>
</div>

    </div>
    <div class="product__sidebar__comment">
        <div class="section-title">
            <h5>New Comment</h5>
        </div>
        <div class="container">
        <div class="container">
        <div class="container">
    <div class="row">
        @foreach ($comics->slice(0, 4) ?? [] as $comic)
        <div class="col-md-12 mb-4">
            <div class="card">
                <div class="row no-gutters">
                    <div class="col-md-4">
                        <img src="{{ asset('storage/cover_images/' . $comic->cover_image) }}" class="card-img" alt="{{ $comic->title }}">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <ul class="list-unstyled">
                                <li>OnGoing</li>
                            </ul>
                            <h5 class="card-title"><a href="#">{{ $comic->title }}</a></h5>
                            <p class="card-text"><i class="fa fa-eye"></i> 19,141 Views</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endforeach
    </div>
</div>

</div>

</div>


    </div>
</div>
</div>
</div>
</div>
</section>
@endsection
