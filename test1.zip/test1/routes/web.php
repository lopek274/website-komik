<?php
use App\Http\Controllers\AuthController;
use App\Http\Controllers\UserViewController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
// Bagian Admin
Route::middleware(['auth', 'role:admin'])->group(function () {
    Route::get('/admin', 'ComicController@index')->name('comics.index');
    Route::get('/create', 'ComicController@create')->name('create');
    Route::post('/comics', 'ComicController@store')->name('comics.store');
    Route::get('/comics/{comic}/edit', 'ComicController@edit')->name('comics.edit');
    Route::put('/comics/{comic}', 'ComicController@update')->name('comics.update');
    Route::delete('/comics/{comic}', 'ComicController@destroy')->name('comics.destroy');
    Route::get('/comics', 'ComicController@index')->name('comics.index');
    Route::get('/comics/search', 'ComicController@search')->name('comics.search');
    Route::get('/change-password', [AuthController::class, 'showChangePasswordForm'])->name('password.change');
    Route::post('/change-password', [AuthController::class, 'changePassword'])->name('password.update');
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

});
Route::get('/registeradmi', [AuthController::class, 'showRegistrationForm'])->name('register');
    Route::post('/registeradmin', [AuthController::class, 'register'])->name('register.submit');

Route::group(['middleware' => ['guest']], function () {
    // menampilkan from login pada awal masuk ke dasboard admin
    Route::get('/loginadmin', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/loginadmin', [AuthController::class, 'login'])->name('login.submit');
});


// bagian view
Route::get('/', 'ViewController@index')->name('view.index');
Route::get('comics/{id}', 'ViewController@show')->name('view.show');
Route::get('/contact', 'ContactController@show')->name('contact.show');
Route::post('/contact', 'ContactController@mail')->name('contact.mail');
Route::get('/categories', 'ViewController@categories')->name('view.categories');

Route::get('/loginuser', [UserViewController::class, 'showLogin'])->name('loginuser');
Route::post('/loginuser', [UserViewController::class, 'login'])->name('login.post');

Route::get('/registeruser', [UserViewController::class, 'showRegister'])->name('registeruser');
Route::post('/registeruser', [UserViewController::class, 'register'])->name('register.post');

Route::post('/logout', [UserViewController::class, 'logout'])->name('logout');
