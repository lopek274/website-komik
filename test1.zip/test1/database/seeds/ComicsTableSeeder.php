<?php

use Illuminate\Database\Seeder;
use App\Models\Comic;
use Faker\Factory as Faker;

class ComicsTableSeeder extends Seeder
{
    public function run()
    {
        $faker = Faker::create();

        foreach (range(1, 20) as $index) {
            App\Comic::create([
                'title' => $faker->sentence(3),
                'description' => $faker->paragraph,
                'author' => $faker->name,
                'cover_image' => 'placeholder.jpg', // jika menggunakan placeholder, ganti dengan path yang benar
            ]);
        }
    }
}
