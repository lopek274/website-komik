<?php $__env->startSection('content'); ?>

<section class="hero">
    <div class="container">
        <div class="hero__slider owl-carousel">
            <?php $__currentLoopData = $comics->slice(7, 4) ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="hero__items set-bg" data-setbg="<?php echo e(asset('storage/cover_images/' . $comic->cover_image)); ?>">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="hero__text">
                            <h2 class="text-decoration-none text-dark"><?php echo e($comic->title); ?></h2>
                            <p class="card-text; text-decoration-none text-dark" ><?php echo e(Str::limit($comic->description, 100)); ?></p>
                            <a href="<?php echo e(route('view.show', ['id' => $comic->id])); ?>"><span>Read now</span> <i class="fa fa-angle-right"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>


    <section class="product spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="trending__product">
                        <div class="row">
                            <div class="col-lg-8 col-md-8 col-sm-8">
                                <div class="section-title">
                                    <h4>Trending Now</h4>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-4">
                                <div class="btn__all">
                                    <a href="#" class="primary-btn">View All <span class="arrow_right"></span></a>
                                </div>
                            </div>
                        </div>
                        <div class="row">
    <?php $__currentLoopData = $comics->slice(0, 6) ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4 mb-4">
        <div class="card h-100">
            <a href="<?php echo e(route('view.show', ['id' => $comic->id])); ?>">
                <img src="<?php echo e(asset('storage/cover_images/' . $comic->cover_image)); ?>" class="card-img-top" alt="<?php echo e($comic->title); ?>">
            </a>
            <div class="card-body">
                <h5 class="card-title">
                    <a href="<?php echo e(route('view.show', ['id' => $comic->id])); ?>" class="text-decoration-none text-dark"><?php echo e($comic->title); ?></a>
                </h5>
                <p class="card-text"><?php echo e(Str::limit($comic->description, 100)); ?></p> <!-- Batasi deskripsi menjadi maksimal 100 karakter -->
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
                    </div>
                    <div class="popular__product">
                        <div class="row">
                            <div class="col-lg-8 col-md-8 col-sm-8">
                                <div class="section-title">
                                    <h4>Popular Shows</h4>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-4">
                                <div class="btn__all">
                                    <a href="#" class="primary-btn">View All <span class="arrow_right"></span></a>
                                </div>
                            </div>
                        </div>
                        <div class="row">
    <?php $__currentLoopData = $comics->slice(6, 6) ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4 mb-4">
        <div class="card h-100">
            <a href="<?php echo e(route('view.show', ['id' => $comic->id])); ?>">
                <img src="<?php echo e(asset('storage/cover_images/' . $comic->cover_image)); ?>" class="card-img-top" alt="<?php echo e($comic->title); ?>">
            </a>
            <div class="card-body">
                <h5 class="card-title">
                    <a href="<?php echo e(route('view.show', ['id' => $comic->id])); ?>" class="text-decoration-none text-dark"><?php echo e($comic->title); ?></a>
                </h5>
                <p class="card-text"><?php echo e(Str::limit($comic->description, 100)); ?></p> <!-- Batasi deskripsi menjadi maksimal 100 karakter -->
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

                    </div>
                    <div class="recent__product">
                        <div class="row">
                            <div class="col-lg-8 col-md-8 col-sm-8">
                                <div class="section-title">
                                    <h4>Recently Added Shows</h4>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-4">
                                <div class="btn__all">
                                    <a href="#" class="primary-btn">View All <span class="arrow_right"></span></a>
                                </div>
                            </div>
                        </div>
                        <<div class="row">
    <?php $__currentLoopData = $comics->slice(12, 6) ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4 mb-4">
        <div class="card h-100">
            <a href="<?php echo e(route('view.show', ['id' => $comic->id])); ?>">
                <img src="<?php echo e(asset('storage/cover_images/' . $comic->cover_image)); ?>" class="card-img-top" alt="<?php echo e($comic->title); ?>">
            </a>
            <div class="card-body">
                <h5 class="card-title">
                    <a href="<?php echo e(route('view.show', ['id' => $comic->id])); ?>" class="text-decoration-none text-dark"><?php echo e($comic->title); ?></a>
                </h5>
                <p class="card-text"><?php echo e(Str::limit($comic->description, 100)); ?></p> 
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

                    </div>
                    
                </div>
                <div class="col-lg-4 col-md-6 col-sm-8">
                    <div class="product__sidebar">
                        <div class="product__sidebar__view">
                            <div class="section-title">
                                <h5>Top Views</h5>
                            </div>
                            <ul class="filter__controls">
                                <li class="active" data-filter="*">Day</li>
                                <li data-filter=".week">Week</li>
                                <li data-filter=".month">Month</li>
                                <li data-filter=".years">Years</li>
                            </ul>
                            <div class="filter__gallery">
    <div class="row">
    <!-- Day Category -->
    <div class="col-md-6">
        <?php $__currentLoopData = $comics->slice(0, 2) ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="product__sidebar__view__item set-bg mix day"
             data-setbg="<?php echo e(asset('storage/cover_images/' . $comic->cover_image)); ?>">
            <a href="<?php echo e(route('view.show', ['id' => $comic->id])); ?>" class="text-decoration-none text-dark">
                <h5><?php echo e($comic->title); ?></h5>
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Week Category -->
    <div class="col-md-6">
        <?php $__currentLoopData = $comics->slice(2, 2) ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="product__sidebar__view__item set-bg mix week"
             data-setbg="<?php echo e(asset('storage/cover_images/' . $comic->cover_image)); ?>">
            <a href="<?php echo e(route('view.show', ['id' => $comic->id])); ?>" class="text-decoration-none text-dark">
                <h5><?php echo e($comic->title); ?></h5>
            </a>
            
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Month Category -->
    <div class="col-md-6">
        <?php $__currentLoopData = $comics->slice(4, 2) ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="product__sidebar__view__item set-bg mix month"
             data-setbg="<?php echo e(asset('storage/cover_images/' . $comic->cover_image)); ?>">
            <a href="<?php echo e(route('view.show', ['id' => $comic->id])); ?>" class="text-decoration-none text-dark">
                <h5><?php echo e($comic->title); ?></h5>
            </a>
           
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Years Category -->
    <div class="col-md-6">
        <?php $__currentLoopData = $comics->slice(6, 2) ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="product__sidebar__view__item set-bg mix years"
             data-setbg="<?php echo e(asset('storage/cover_images/' . $comic->cover_image)); ?>">
            <a href="<?php echo e(route('view.show', ['id' => $comic->id])); ?>" class="text-decoration-none text-dark">
                <h5><?php echo e($comic->title); ?></h5>
            </a>
           
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

    </div>
    <div class="product__sidebar__comment">
        <div class="section-title">
            <h5>New Comment</h5>
        </div>
        <div class="container">
        <div class="container">
        <div class="container">
    <div class="row">
        <?php $__currentLoopData = $comics->slice(0, 4) ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-12 mb-4">
            <div class="card">
                <div class="row no-gutters">
                    <div class="col-md-4">
                        <img src="<?php echo e(asset('storage/cover_images/' . $comic->cover_image)); ?>" class="card-img" alt="<?php echo e($comic->title); ?>">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <ul class="list-unstyled">
                                <li>OnGoing</li>
                            </ul>
                            <h5 class="card-title"><a href="#"><?php echo e($comic->title); ?></a></h5>
                            <p class="card-text"><i class="fa fa-eye"></i> 19,141 Views</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

</div>

</div>


    </div>
</div>
</div>
</div>
</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layoutsview.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web Komik\resources\views/view/index.blade.php ENDPATH**/ ?>