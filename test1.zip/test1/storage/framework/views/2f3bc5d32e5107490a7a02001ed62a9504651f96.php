<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <h2><?php echo e($comic->title); ?></h2>
                <img src="<?php echo e(asset('storage/' . $comic->cover_image)); ?>" class="img-fluid mb-3" alt="<?php echo e($comic->title); ?>">
                <p><?php echo e($comic->description); ?></p>
                <p><strong>Author:</strong> <?php echo e($comic->author); ?></p>
                <a href="<?php echo e(route('comics.index')); ?>" class="btn btn-secondary">Kembali ke Daftar Komik</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\test1\resources\views/comics/show.blade.php ENDPATH**/ ?>