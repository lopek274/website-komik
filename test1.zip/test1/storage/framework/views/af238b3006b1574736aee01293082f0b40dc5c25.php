<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Daftar Komik</h1>
        <form action="<?php echo e(route('comics.search')); ?>" method="GET" class="form-inline mb-3">
        <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" name="search">
        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
         </form>

         <div class="row">
    <?php $__currentLoopData = $comics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3">
            <div class="card mb-4">
                <img src="<?php echo e(asset('storage/cover_images/' . $comic->cover_image)); ?>" class="card-img-top" alt="<?php echo e($comic->title); ?>">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($comic->title); ?></h5>
                    <a href="<?php echo e(route('comics.edit', $comic->id)); ?>" class="btn btn-warning">Edit</a>
                    <form action="<?php echo e(route('comics.destroy', $comic->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus komik ini?')">Hapus</button>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layoutsAdmin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\test1\resources\views/comics/index.blade.php ENDPATH**/ ?>