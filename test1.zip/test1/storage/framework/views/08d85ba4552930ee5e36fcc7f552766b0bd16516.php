<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="description" content="Anime Template">
    <meta name="keywords" content="Anime, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Title of Your Page</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Mulish:wght@300;400;500;600;700;800;900&display=swap"
          rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('asset/css/bootstrap.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('asset/css/font-awesome.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('asset/css/elegant-icons.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('asset/css/plyr.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('asset/css/nice-select.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('asset/css/owl.carousel.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('asset/css/slicknav.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('asset/css/style.css')); ?>" type="text/css">
</head>
<body>
<header class="header">
    <div class="container">
        <div class="row">
            <div class="col-lg-2">
                <div class="header__logo">
                    <a href="<?php echo e(url('/')); ?>">
                        <img src="<?php echo e(asset('asset/img/logoweb.png')); ?>" alt="">
                    </a>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="header__nav">
                    <nav class="header__menu mobile-menu">
                        <ul>
                            <li class="active"><a href="<?php echo e(url('/')); ?>">Homepage</a></li>
                            <li><a href="#">Categories <span class="arrow_carrot-down"></span></a>
                                <ul class="dropdown">
                                <li><a href="<?php echo e(url('/categories')); ?>">Categories1</a></li>
                                <li><a href="<?php echo e(url('/categories')); ?>">Categories2</a></li>
                                <li><a href="<?php echo e(url('/categories')); ?>">Categories3</a></li>                              
                                </ul>
                            </li>
                            <li><a href="<?php echo e(url('/contact')); ?>">Contacts</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
            <div class="col-lg-2">
                <div class="header__right">
                    <a href="#" class="search-switch"><span class="icon_search"></span></a>
                    <a href="<?php echo e(url('/loginuser')); ?>"><span class="icon_profile"></span></a>
                </div>
            </div>
        </div>
        <div id="mobile-menu-wrap"></div>
    </div>
</header>

<div id="preloder">
    <div class="loader"></div>
</div>

<?php echo $__env->yieldContent('content'); ?>

<!-- Footer Section Begin -->
<footer class="footer">
    <div class="page-up">
        <a href="#" id="scrollToTopButton"><span class="arrow_carrot-up"></span></a>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-3">
                <div class="footer__logo">
                    <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('asset/img/logoweb.png')); ?>" alt=""></a>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="footer__nav">
                    <ul>
                        <li class="active"><a href="<?php echo e(url('/')); ?>">Homepage</a></li>
                        <li><a href="<?php echo e(url('/')); ?>">Categories</a></li>
                        <li><a href="<?php echo e(url('/contact')); ?>">Contacts</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3">
                <p>
                    Copyright &copy;<script>document.write(new Date().getFullYear());</script> Komik+62
                </p>
            </div>
        </div>
    </div>
</footer>
<!-- Footer Section End -->
 <!-- Search Model -->
 <div class="search-model">
        <div class="h-100 d-flex align-items-center justify-content-center">
            <div class="search-close-switch"><i class="icon_close"></i></div>
            <form class="search-model-form">
                <input type="text" id="search-input" placeholder="Search here.....">
            </form>
        </div>
    </div>
    

<script src="<?php echo e(asset('asset/js/jquery-3.3.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/js/player.js')); ?>"></script>
<script src="<?php echo e(asset('asset/js/jquery.nice-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/js/mixitup.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/js/jquery.slicknav.js')); ?>"></script>
<script src="<?php echo e(asset('asset/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/js/main.js')); ?>"></script>

</body>
</html>
<?php /**PATH F:\test1\resources\views/layoutsView/main.blade.php ENDPATH**/ ?>