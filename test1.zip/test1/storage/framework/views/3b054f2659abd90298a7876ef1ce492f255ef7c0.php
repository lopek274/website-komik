<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
    <div class="col-md-8 text-white">
    <h2><?php echo e($comic->title); ?></h2>
    <p><strong>Author:</strong> <?php echo e($comic->author); ?></p>
    <p><?php echo e($comic->description); ?></p>
    <img src="<?php echo e(asset('storage/cover_images/' . $comic->cover_image)); ?>" class="img-fluid mb-3" alt="<?php echo e($comic->title); ?>">
</div>
    </div> 
    <div>
        <a href="<?php echo e(route('view.index')); ?>" class="btn btn-secondary">Kembali ke halaman awal</a>
    </div>
</div>

<?php $__env->stopSection(); ?>
<script src="asset/js/jquery-3.3.1.min.js"></script>
<script src="asset/js/bootstrap.min.js"></script>
<script src="asset/js/player.js"></script>
<script src="asset/js/jquery.nice-select.min.js"></script>
<script src="asset/js/mixitup.min.js"></script>
<script src="asset/js/jquery.slicknav.js"></script>
<script src="asset/js/owl.carousel.min.js"></script>
<script src="asset/js/main.js"></script>

<!-- Google Font -->
<link href="https://fonts.googleapis.com/css2?family=Oswald:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Mulish:wght@300;400;500;600;700;800;900&display=swap"
    rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="asset/css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="asset/css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="asset/css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="asset/css/plyr.css" type="text/css">
    <link rel="stylesheet" href="asset/css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="asset/css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="asset/css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="asset/css/style.css" type="text/css">
<?php echo $__env->make('layoutsView.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\test1\resources\views/view/show.blade.php ENDPATH**/ ?>